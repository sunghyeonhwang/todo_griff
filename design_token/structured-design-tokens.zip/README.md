# Structured Planner — Design Tokens v1.0.0

Structured 스타일 데일리 타임블록 플래너용 디자인 토큰 패키지입니다.

## 파일 구성

| 파일 | 용도 |
|------|------|
| `design-tokens.json` | 원본 토큰 (단일 진실 공급원, 도구 변환용) |
| `tokens.css` | CSS 변수 — light/dark 자동 전환 포함 |
| `tokens.ts` | TypeScript 상수 — 로직·스토어에서 타입 안전하게 참조 |
| `tailwind.config.js` | Tailwind theme.extend 설정 |
| `preview.html` | 토큰 시각 미리보기 (브라우저에서 열기) |

## 사용법

### 1) CSS 변수
```html
<link rel="stylesheet" href="tokens.css">
```
```css
.card { background: var(--surface-card); box-shadow: var(--shadow-md); border-radius: var(--radius-lg); }
```

### 2) Tailwind
`tailwind.config.js`를 프로젝트 루트에 두고, `index.css`에 `tokens.css`를 import 하세요
(surface/content 색상이 CSS 변수를 참조하므로 다크모드가 자동 반영됩니다).
```jsx
<div className="bg-surface-card text-content-primary rounded-lg shadow-md" />
<div className="bg-block-blue-bg text-block-blue-fg border-l-4 border-block-blue-solid" />
```

### 3) TypeScript (로직)
```ts
import { BLOCK_COLORS, LAYOUT, type BlockColor } from './tokens';
const top = block.startMinutes * LAYOUT.pxPerMinute;
const { solid } = BLOCK_COLORS[block.color as BlockColor];
```

## 다크모드 전략
- **자동:** 시스템 설정(`prefers-color-scheme`)을 따름
- **수동:** `<html data-theme="dark">` 또는 `data-theme="light"`로 강제
- Tailwind의 `dark:` 유틸을 병행하려면 `class="dark"` 토글 + `darkMode:'class'` 사용

## 레이아웃 핵심 상수
- 1시간 = **64px**, 1분 = **1.0667px**
- 시간 라벨 컬럼 = **60px**, 스냅 단위 = **15분**
- 앱 최대 너비 = **480px** (모바일 우선)
